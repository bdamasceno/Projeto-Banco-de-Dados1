<?php

class Conexao
{
	 static public $servername = "localhost:3306";
	 static public $username = "root";
	 static public $password = "Damasceno123";

	

	function desconecta()
	{
	mysqli_close($conn);
	}
	public static function conectar()
	{
		// Create connection
	$conn = new mysqli(Conexao::$servername, Conexao::$username, Conexao::$password);

	// Check connection
	if ($conn->connect_error) {
 	   die("Connection failed: " . $conn->connect_error);
	}
	echo "Connected successfully";	
	}

}






?>