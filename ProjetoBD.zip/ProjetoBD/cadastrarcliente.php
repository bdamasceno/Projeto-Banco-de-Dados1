<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if ($conn->connect_error) {
 	   die("Connection failed: " . $conn->connect_error);
	}
	echo "Connected successfully";

	$nome = $sexo = $idade = $login = $senha = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
 	$nome = test_input($_POST["nome"]);
  	$sexo = test_input($_POST["sexo"]);
  	$idade = test_input($_POST["idade"]);
  	$login = test_input($_POST["login"]);
  	$senha = test_input($_POST["senha"]);
	}

	function test_input($data) {
  	$data = trim($data);
  	$data = stripslashes($data);
  	$data = htmlspecialchars($data);
  	return $data;
	}

	echo "<h2>Your Input:</h2>";
	echo $nome;
	echo "<br>";
	echo $sexo;
	echo "<br>";
	echo $idade;
	echo "<br>";
	echo $login;
	echo "<br>";	
	echo $senha;
?>