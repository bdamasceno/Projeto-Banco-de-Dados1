<?php 

	class Cliente
	{
	$idCliente = '';
	$nome ='';
	$sexo ='';
	$idade = '';
	$login = '';
	$senha = '';
	$telefones_numero= '';
	$enderecos_id_endereco = '';

	}

class Enderecos
{
	$idEndereco = '';
	$rua = '';
	$bairro = '';
	$numero = '';
	$complemento = '';
	$cidade = '';
	$estado = '';


}

class Pedidos
{
	$idPedido = '';
	$endereco_id_endereco = '';
	$produto_id = '';
	

}

class Telefones
{

}

class Funcionarios
{

}

class Pedidos
{

}

class Bebida
{

}

class Pizza
{

}










?>