<?php
  include 'conecta.php';
  $conn= Conexao::conectar();
               
  if (!$conn) {
    die("Error: " . mysqli_connect_error());
  }

  $id="";

  if($_GET['id']) {
    $id = $_GET['id'];
  }

  $sql = "DELETE FROM Usuarios WHERE idUsuario = '".$id."'";
  echo " ".$sql." ";
  
  $sql1 = "DELETE FROM Clientes WHERE idUsuario = '".$id."'";
  if (mysqli_query($conn, $sql)) {
      echo "Record successfully deleted";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  if (mysqli_query($conn, $sql1)) {
      echo "Record successfully deleted";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }


  mysqli_close($conn);

?>