<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if (!$conn) {
 	   die("Error: " . mysqli_connect_error());
	}
	echo "Connected Successfully";

	$sexo = $idade = $id="";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$sexo = $_POST["sexo"];
	  	$idade = $_POST["idade"];
	  	
	}

	$id = "SELECT idUsuario FROM Usuario ORDER BY idUsuario DESC LIMIT 1";
	$id = mysqli_fetch_assoc(mysqli_query($conn, $id));
	echo $id['idUsuario'];

	$sql = "INSERT INTO Clientes (sexo, idade, idUsuario)
			VALUES ('".$_POST["sexo"]."',
					'".$_POST["idade"]."',
					'".$id['idUsuario']."')";
	
	if (mysqli_query($conn, $sql)) {
    	echo "New record created successfully";
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	
	mysqli_close($conn);

?>