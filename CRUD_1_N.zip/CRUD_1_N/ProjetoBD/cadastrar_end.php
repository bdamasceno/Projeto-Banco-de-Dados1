<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if (!$conn) {
 	   die("Error: " . mysqli_connect_error());
	}
	echo "Connected Successfully";

	$rua = $bairro = $numero = $complemento = $cidade = $estado ="";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 	$rua = $_POST["rua"];
		$bairro = $_POST["bairro"];
	  	$numero = $_POST["numero"];
	  	$complemento = $_POST["complemento"];
	  	$cidade = $_POST["cidade"];
	  	$estado = $_POST["estado"];
	}


	$sql = "INSERT INTO Enderecos (rua, bairro, numero, complemento, cidade, estado)
			VALUES ('".$_POST["rua"]."',
					'".$_POST["bairro"]."',
					'".$_POST["numero"]."',
					'".$_POST["complemento"]."',
					'".$_POST["cidade"]."',
					'".$_POST["estado"]."')";
	if (mysqli_query($conn, $sql)) {
    	echo "New record created successfully";
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);

?>