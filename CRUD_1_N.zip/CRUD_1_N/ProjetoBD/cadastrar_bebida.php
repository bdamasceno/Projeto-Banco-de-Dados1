<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if (!$conn) {
 	   die("Error: " . mysqli_connect_error());
	}
	echo "Connected Successfully";

	$nome = $tamanho = $preco="";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 	$nome = $_POST["nome"];
		$tamanho = $_POST["tamanho"];
		$preco = $_POST["preco"];
	}


	$sql = "INSERT INTO Bebidas (nome, tamanho, preco)
			VALUES ('".$_POST["nome"]."',
					'".$_POST["tamanho"]."',
					'".$_POST["preco"]."')";
	if (mysqli_query($conn, $sql)) {
    	echo "New record created successfully";
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);

?>