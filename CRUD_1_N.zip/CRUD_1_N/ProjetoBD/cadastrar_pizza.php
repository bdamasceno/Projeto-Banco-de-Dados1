<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if (!$conn) {
 	   die("Error: " . mysqli_connect_error());
	}
	echo "Connected Successfully";

	$nome = $precoP = $precoM = $precoG = $ingredientes ="";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 	$nome = $_POST["nome"];
		$precoP = $_POST["precoP"];
	  	$precoM = $_POST["precoM"];
	  	$precoG = $_POST["precoG"];
	  	$ingredientes = $_POST["ingredientes"];
	}


	$sql = "INSERT INTO Pizzas (nome, precoP, precoM, precoG, ingredientes)
			VALUES ('".$_POST["nome"]."',
					'".$_POST["precoP"]."',
					'".$_POST["precoM"]."',
					'".$_POST["precoG"]."',
					'".$_POST["ingredientes"]."')";
	if (mysqli_query($conn, $sql)) {
    	echo "New record created successfully";
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);

?>