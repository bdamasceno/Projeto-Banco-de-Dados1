<?php  
	
	include 'conecta.php';
	$conn= Conexao::conectar();

	if (!$conn) {
 	   die("Error: " . mysqli_connect_error());
	}
	echo "Connected Successfully";

	$login = $senha = $nome="";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 	$login = $_POST["login"];
		$senha = $_POST["senha"];
	  	$nome = $_POST["nome"];
	}


	$sql = "INSERT INTO Usuario (login, senha, nome)
			VALUES ('".$_POST["login"]."',
					'".$_POST["senha"]."',
					'".$_POST["nome"]."')";
				
	if (mysqli_query($conn, $sql)) {
    	echo "New record created successfully";
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	
	mysqli_close($conn);

?>