<?php
  include 'conecta.php';
  $conn= Conexao::conectar();
               
  if (!$conn) {
    die("Error: " . mysqli_connect_error());
  }

  $login = $senha = $nome = $idade = $sexo = $idUsuario="";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $login = $_POST["login"];
      $senha = $_POST["senha"];
      $nome = $_POST["nome"];
      $idade = $_POST["idade"];
      $sexo = $_POST["sexo"];
      $idUsuario = $_POST["idUsuario"];
  }


  $sql = "UPDATE Usuario SET   login            = '".$_POST["login"]."',
                               senha            = '".$_POST["senha"]."',
                               nome             = '".$_POST["nome"]."'
                               WHERE idUsuario  = '".$_POST["idUsuario"]."'  ";

  $sql1 = "UPDATE Clientes SET idade            = '".$_POST["idade"]."',
                               sexo             = '".$_POST["sexo"]."'
                               WHERE idUsuario  = '".$_POST["idUsuario"]."'  ";




  echo " ".$sql." ";
  echo " ".$sql1." ";

  if (mysqli_query($conn, $sql)) {
      echo "Record successfully updated";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  if (mysqli_query($conn, $sql1)) {
      echo "Record successfully updated";
  } else {
      echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);

?>