<?php
  include 'conecta.php';
  $conn= Conexao::conectar();
               
  if (!$conn) {
    die("Error: " . mysqli_connect_error());
  }

  $rua = $bairro = $numero = $complemento = $cidade = $estado = $id="";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $rua = $_POST["rua"];
      $bairro = $_POST["bairro"];
      $numero = $_POST["numero"];
      $complemento = $_POST["complemento"];
      $cidade = $_POST["cidade"];
      $estado = $_POST["estado"];
      $id= $_POST["id"];
  }


  $sql = "UPDATE Enderecos SET rua              = '".$_POST["rua"]."',
                               bairro           = '".$_POST["bairro"]."',
                               numero           = '".$_POST["numero"]."',
                               complemento      = '".$_POST["complemento"]."',
                               cidade           = '".$_POST["cidade"]."',
                               estado           = '".$_POST["estado"]."'
                               WHERE idEndereco = '".$_POST["id"]."'  "; 
  echo " ".$sql." ";
  if (mysqli_query($conn, $sql)) {
      echo "Record successfully updated";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  mysqli_close($conn);

?>